const assert = require('assert');
const Comercios = artifacts.require('Comercios');

contract('Comercios', () => {
  beforeEach(async () => {
    this.comercios = await Comercios.new();
  });
  it('Crear Comercio', async () => {
    await this.comercios.crearComercio("Bocata","323232","Montevideo","8 de octubre","232323",99999," ","0x1597C7Df9DFc0C347E1149a2725D3Cb887153026");

    //const message = await this.helloWorld.getMessage();

    //assert.equal(message, 'Goodbye.');
  });
  

  it('Informacion del Comercio', async () => {
    const message = await this.comercios.myInfo();

  });
  
});

