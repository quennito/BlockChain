const TokenSocialUruguay = artifacts.require("TokenSocialUruguay");
const Beneficiarios = artifacts.require("Beneficiarios");
const Comercios = artifacts.require("Comercios");

module.exports = function(deployer){
    
    deployer.deploy(TokenSocialUruguay);
    deployer.deploy(Beneficiarios);
    deployer.deploy(Comercios);
    };